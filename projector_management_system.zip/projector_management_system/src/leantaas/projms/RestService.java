package leantaas.projms;

import jdk.nashorn.internal.objects.annotations.Getter;
import java.util.ArrayList;

import javax.print.attribute.standard.Media;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/MyRestService")
@ApplicationPath("resources")
public class RestService extends Application {

    @GET
    @Path("/sayHello")
    // @Produces(MediaType.APPLICATION_JSON)
    public String getHelloMsg() {
        return "Hello World";
    }
}