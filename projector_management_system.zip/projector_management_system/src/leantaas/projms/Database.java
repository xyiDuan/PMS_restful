package leantaas.projms;

import java.util.HashMap;
import java.util.Map;

public class Database {
    private static Map<Integer, Projector> projectors = new HashMap<>();
    // static Map<Integer, User> users = new HashMap<>();

    public static Map<Integer, Projector> getProjectors() {
        return projectors;
    }

//    public static Map<Integer, User> getUser() {
//
//        return users;
//    }

    static {
        // hardcoded projectors
        projectors.put(1, new Projector(1));
        projectors.put(2, new Projector(2));
        projectors.put(3, new Projector(3));
        projectors.put(4, new Projector(4));
        projectors.put(5, new Projector(5));
        projectors.put(6, new Projector(6));
        projectors.put(7, new Projector(7));
        projectors.put(8, new Projector(8));
        projectors.put(9, new Projector(9));
        projectors.put(10, new Projector(10));
    }
}
