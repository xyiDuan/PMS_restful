package leantaas.projms;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.print.attribute.standard.RequestingUserName;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Reservation implements Comparable {
    // private int userID;
    private int pid;
    private String reserveID;
    private String startTime;
    private String endTime;

    public Reservation () {

    }

    public Reservation(String startTime, String endTime, int pid, String reserveID) {
        super();
        // this.userID = userID;
        this.pid = pid;
        this.reserveID = reserveID;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getReserveID() {

        return reserveID;
    }

    public String getStartTime() {

        return startTime;
    }

    public String getEndTime() {

        return endTime;
    }

    public void setStartTime(String startTime) {

        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {

        this.endTime = endTime;
    }

    @Override
    public int compareTo(Object o) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        try {
            Date timeOne = sdf.parse(((Reservation)o).getStartTime());
            Date timeTwo = sdf.parse(this.startTime);
            return (int) (timeTwo.getTime() - timeOne.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof Reservation)) {
            return false;
        }
        Reservation object = (Reservation) o;
        if (this.endTime.equals(object.endTime) && this.startTime.equals(object.startTime)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {

        return super.hashCode();
    }
}
