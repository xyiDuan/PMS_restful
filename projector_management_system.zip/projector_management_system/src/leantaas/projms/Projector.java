package leantaas.projms;

import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class Projector {
    private int pid;
    private List<Reservation> reservations = new ArrayList<>();

    public Projector () {

    }

    public Projector(int pid) {

        this.pid = pid;
    }

    public int getPid() {

        return pid;
    }

    public void setPid(int pid) {

        this.pid = pid;
    }

    public List<Reservation> getReservations() {

        return reservations;
    }

    public Reservation addReservation(TimeDuration newTime) {
        if (newTime == null) return null;
        else {
            String length = String.valueOf(reservations.size());
            Reservation r = new Reservation(newTime.getStartTime(), newTime.getEndTime(),
                            pid, String.valueOf(pid) + "-" + length);
            reservations.add(r);
            return r;
        }
    }

    public boolean removeReservation(int pos) {
        if (pos < 0 || pos >= reservations.size()) {
            return false;
        } else {
            reservations.set(pos, null) ;
            return true;
        }
    }

    /**
     * check if the new time duration has conflicts with projector's reservation list
     * @param newReservation date, start time, end time
     * @return true or false
     */
    public boolean checkValidity(TimeDuration newReservation) throws ParseException {
        if (newReservation == null) {
            return false;
        } else {
            if (reservations.isEmpty()) {
                return true;
            } else {
                for (Reservation rr : reservations) {
                    if (rr == null) {
                        continue;
                    }
                    if (rr.getStartTime().compareTo(newReservation.getStartTime()) >= 0
                            && rr.getEndTime().compareTo(newReservation.getEndTime()) <= 0) {
                        return false;
                    } else if (rr.getStartTime().compareTo(newReservation.getStartTime()) <= 0
                            && rr.getEndTime().compareTo(newReservation.getEndTime()) >= 0) {
                        return false;
                    } else if (rr.getStartTime().compareTo(newReservation.getStartTime()) >= 0
                            && rr.getEndTime().compareTo(newReservation.getEndTime()) >= 0
                            && rr.getStartTime().compareTo(newReservation.getEndTime()) <= 0) {
                        return false;
                    } else if (rr.getStartTime().compareTo(newReservation.getStartTime()) <= 0
                            && rr.getEndTime().compareTo(newReservation.getEndTime()) <= 0
                            && rr.getEndTime().compareTo(newReservation.getStartTime()) >= 0) {
                        return false;
                    }
                }
                return true;
            }
        }

    }
}
