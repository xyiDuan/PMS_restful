package leantaas.projms;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.DELETE;

import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.MediaType;

/**
 * Restful Service for projector management
 */

@Path("/pm")
public class PMSResources extends ApplicationExceptionMapper{
    ManagementModule management = new ManagementModule();

    /**
     * display all projectors' name
     * @return projectors' name
     */
    @Path("/projectors")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> getAllProjectors() {
        List<String> pNameList = new ArrayList<>();
        for (Projector p : management.getAllProjectors()) {
            pNameList.add("P" + String.valueOf(p.getPid()));
        }
        return pNameList;
    }

    /**
     * reserve a projector
     * @param time - an object includes date, start time and end time
     * @return reservation details
     */
    @Path("/reservation")
    @POST
    @Produces(MediaType.TEXT_PLAIN)
    @Consumes(MediaType.APPLICATION_JSON)
    public String reserveProjector(TimeDuration time) throws ParseException, WebApplicationException {

        String result = management.reserveDuration(time); // reservation ID
        if (result.equals("-1")) {
            Set<TimeDuration> availableSet = management.checkAvailabilityList(time);
            String s = "Your reservation is not available. Next availability is at: ";
            for (TimeDuration t: availableSet) {
                s += "StartTime: " + t.getStartTime() + "\t" + "EndTime: " + t.getEndTime() + "\n";
            }
            return s;

        } else if (result.equals("-2")) {
            return "Please check your timings and reserve again.";
        }
        else {
            String pid = result.split("-")[0];

            return ("Reservation booked in Projector, here is the details: \n" +
                    "Projector name: P" + pid + "\n" + "Reservation ID: " + result + "\n" +
                    "Start Time: " + time.getStartTime() + "\n" +
                    "End Time: " + time.getEndTime());
        }
    }

    /**
     * @return Get all the reservations
     */
    @Path("/reservation")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Reservation> getAllReservation() {
        return management.getAllReservation();
    }

    /**
     * Cancel a reservation by given id
     * @param id reservation id
     * @return status
     */
    @Path("reservation/{id}")
    @DELETE
    @Produces(MediaType.TEXT_PLAIN)
    @Consumes(MediaType.APPLICATION_JSON)
    public String cancelReservation(@PathParam("id") String id) {
       boolean result = management.cancelAReservation(id);

        if(result) {
            return "Reservation is cancelled";
        } else {
            return "Process failed, reservation id invalid.";
        }
    }

    /**
     * get reservation details by given id
     * @param id reservation id
     * @return details
     */
    @Path("reservation/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Reservation  getReservationByID(@PathParam("id") String id) {
        return management.getAReservationByID(id);
    }

    /**
     * Show a given projector's possible reservation durations.
     * @param id projector id
     * @return possible duration for {id} projector
     */
    @Path("projectors/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<TimeDuration> checkAvailabilityForProjector(@PathParam("id") int id) throws ParseException {
        return management.getAvailableDuration(id);
    }
}
