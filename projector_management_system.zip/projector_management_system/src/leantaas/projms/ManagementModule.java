package leantaas.projms;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;

import java.util.concurrent.TimeUnit;

public class ManagementModule {
    Map<Integer, Projector> projectors = Database.getProjectors();

    public ManagementModule() {

    }

    public List<Projector> getAllProjectors() {

        return new ArrayList<>(projectors.values());
    }

    public List<Reservation> getAllReservation() {
        List<Reservation> reservations = new ArrayList<>();
        for (Projector p : projectors.values()) {
            reservations.addAll(p.getReservations());

        }
        return reservations;
    }

    /**
     * for checking available times, we need to sort the reservations first
     * @param pid projector id
     * @return sorted reservation list
     */
    @SuppressWarnings("unchecked")
    private List<Reservation> getSortedProjectorReservation(int pid) {
        List<Reservation> rList = new ArrayList<>(projectors.get(pid).getReservations());
        // rList.addAll(projectors.get(pid).getReservations());
        Collections.sort(rList);
        return rList;
    }

    /**
     * show projector{id}'s all available times
     * @param pid projector id
     * @return all available time
     */
    public List<TimeDuration> getAvailableDuration(int pid) throws ParseException {
        List<Reservation> rList = getSortedProjectorReservation(pid);
        List<TimeDuration> availableList = new ArrayList<>();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = new Date(); // current date
        String currentDate = dateFormat.format(date);
        if (rList.get(0).getStartTime().compareTo(currentDate) != 0) {
            TimeDuration first = new TimeDuration("Available time starting from " + currentDate, rList.get(0).getStartTime());
            availableList.add(first);
        }
        for (int i = 0; i < rList.size() - 1; i ++) {
            if (rList.get(i) == null) {
                continue;
            }

            if(rList.get(i).getEndTime().compareTo(rList.get(i+1).getStartTime()) < 0) {
                TimeDuration possibleDuration = new TimeDuration(rList.get(i).getEndTime(), rList.get(i+1).getStartTime());
                availableList.add(possibleDuration);
            }
        }
        TimeDuration last = new TimeDuration(rList.get(rList.size()-1).getEndTime(), "To 23:59:59");
        availableList.add(last);
        return availableList;

    }

    /**
     * input a duration for reserving a projector
     * @param duration date, start time and end time
     * @return status details
     */
    public String reserveDuration(TimeDuration duration) throws ParseException {
        if (duration == null || duration.getEndTime().compareTo(duration.getStartTime()) <= 0) {
            return "-2";
        }

        for (Projector pro : projectors.values()) {
            if (pro.checkValidity(duration)) {
                Reservation r = pro.addReservation(duration);
                return r.getReserveID();
            }
        }

        return "-1";
    }


    /**
     * Cancel a reservation
     * @param reservationID String, reservation id
     * @return true or false
     */
    public boolean cancelAReservation(String reservationID) {
        try {
            int pid = Integer.valueOf(reservationID.split("-")[0]);
            int pos = Integer.valueOf(reservationID.split("-")[1]);
            return projectors.get(pid).removeReservation((pos));
        } catch (Exception e) {
            return false;
        }

    }

    /**
     * show a reservation's details
     * @param reservationID reservation id
     * @return details
     */
    public Reservation getAReservationByID(String reservationID) {
        try {
            int pid = Integer.valueOf(reservationID.split("-")[0]);
            int pos = Integer.valueOf(reservationID.split("-")[1]);
            return projectors.get(pid).getReservations().get(pos);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * if no projectors are available, provide substitute selections
     * @param durationWithDate date, startime and endtime
     * @return a available time list
     */
    @SuppressWarnings("unchecked")
    public Set<TimeDuration> checkAvailabilityList(TimeDuration durationWithDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date startTime = sdf.parse(durationWithDate.getStartTime());
        Date endTime = sdf.parse(durationWithDate.getEndTime());
        long duration = TimeUnit.MILLISECONDS.toHours(endTime.getTime() - startTime.getTime());
        Set<TimeDuration> availableSet = new HashSet<>();

        for(Projector pro : projectors.values()) {

            String begin = durationWithDate.getStartTime().split(" ")[0] + " 00:00:00";
            List<Reservation> rList = pro.getReservations();
            Collections.sort(rList);

            if (rList.get(0).getStartTime().compareTo(begin) != 0
                    && TimeUnit.MILLISECONDS.toHours(sdf.parse(rList.get(0).getStartTime()).getTime() - sdf.parse(begin).getTime()) > duration) {
                TimeDuration first = new TimeDuration("Available time starting from " + begin, rList.get(0).getStartTime());
                availableSet.add(first);
            }

            for (int i = 0; i < rList.size() - 1; i ++) {
                String start = rList.get(i).getEndTime();
                String end = rList.get(i+1).getStartTime();
                if(start.compareTo(end) < 0 && sdf.parse(end).getTime() - sdf.parse(start).getTime() > duration) {
                    TimeDuration possibleDuration = new TimeDuration(rList.get(i).getEndTime(), rList.get(i+1).getStartTime());
                    availableSet.add(possibleDuration);
                }
            }
            TimeDuration last = new TimeDuration(rList.get(rList.size()-1).getEndTime(), "To next day");
            availableSet.add(last);
        }

        return availableSet;
    }

}

