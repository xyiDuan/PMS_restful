package test;

import leantaas.projms.*;

import org.junit.Test;
import org.junit.Ignore;

import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.text.ParseException;
import java.net.URI;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;

import static org.junit.Assert.assertEquals;

public class TestJunit {

    ManagementModule management = new ManagementModule();
    List<Projector> projectors = management.getAllProjectors();

    @Test
    /**
     * test for displaying all the projectors names
     */
    public void testProjectors() {
        assertEquals(10, projectors.size());
        for (int i = 0; i < 10; i ++) {
            assertEquals(i+1, projectors.get(i).getPid());
        }
        //assertEquals(ProjectorName, management.getAllProjectors());
    }

    @Test
    public void addReservationTest() throws ParseException {
        TimeDuration testTime = new TimeDuration("2018-04-12 11:00:00", "2018-04-12 13:00:00");
        TimeDuration wrongTestTime = new TimeDuration("2018-04-12 13:00:00", "2018-04-12 11:00:00");
        TimeDuration nullTestTime = null;

        System.out.println("Invalid Date Input Test");
        assertEquals("-2", management.reserveDuration(wrongTestTime));
        assertEquals("-2", management.reserveDuration(nullTestTime));
        System.out.println("Success.");

        System.out.println("Reserve for one time slot.");
        for (int i = 0; i < 10; i ++) {
            assertEquals(String.valueOf(i+1) + "-0", management.reserveDuration(testTime));
        }
        // Reserve same time duration for all 10 projectors.
        System.out.println("Success.");

        // No available Time
        assertEquals("-1", management.reserveDuration(testTime));
        System.out.println("Success.");
    }

    @Test
    public void deleteReservationTest() throws ParseException {
        System.out.println("Deletion Test.");
        TimeDuration testTime = new TimeDuration("2018-04-12 11:00:00", "2018-04-12 13:00:00");
        management.reserveDuration(testTime);
        assertEquals(true, management.cancelAReservation("1-0"));
        assertEquals(null, management.getAllProjectors().get(0).getReservations().get(0));
        System.out.println("Success.");
    }

    @Test
    public void getReservationInfoByID() throws ParseException {
        TimeDuration testTime = new TimeDuration("2018-04-12 15:00:00", "2018-04-12 16:00:00");

        management.reserveDuration(testTime);
        Reservation result = management.getAReservationByID("1-1");
        Reservation expectation = new Reservation("2018-04-12 15:00:00", "2018-04-12 16:00:00",
                                                  1, "1-1");
        assertEquals(expectation, result);
    }


}
